# Logistics Data Collection, Cleaning and Preprocessing

## Project overview
This repository demonstrates a repeatable Python preprocessing workflow for shipment/logistics data. It includes a simulated raw sample, cleaning code, a cleaned output, a data-quality audit report, and a machine-readable summary.

**Data note:** `data/logistics_sample_raw.csv` is a synthetic teaching dataset created for this assignment. It is not a real carrier dataset and its statistics must not be presented as actual business findings. The Olist Brazilian E-Commerce Public Dataset is a possible public reference for a future run on real data:
https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce

## What the pipeline covers
- Initial profiling and missing-value counts
- Exact duplicate detection and removal
- Standardization of categorical labels
- Date and numeric type conversion
- Invalid value checks (negative delivery duration, non-positive distance, negative cost)
- Median imputation for numeric columns
- IQR-based freight-cost outlier detection and capping
- Min-max normalization to the range [0, 1]
- CSV outputs, JSON summary, and automated validation assertions

## Repository structure
```text
logistics-data-preprocessing-repository/
├── data/
│   └── logistics_sample_raw.csv
├── src/
│   └── preprocess_logistics.py
├── outputs/
│   ├── logistics_cleaned.csv
│   ├── data_quality_report.csv
│   └── preprocessing_summary.json
├── requirements.txt
└── README.md
```

## How to run
Use Python 3.10+.

```bash
python -m pip install -r requirements.txt
python src/preprocess_logistics.py
```

Run the command from the repository root. The script writes the cleaned dataset and reports into `outputs/`.

## Output files
- `logistics_cleaned.csv`: cleaned rows, outlier flag, capped cost feature, and normalized columns.
- `data_quality_report.csv`: checks and counts recorded before and after processing.
- `preprocessing_summary.json`: concise metrics and validation status.

## Important methodological notes
1. Median imputation is a baseline; check the missingness mechanism before applying it to production data.
2. IQR outliers are candidates for investigation, not automatically erroneous records. Transport mode and route context matter.
3. Original freight cost is retained; a separate capped column is created to avoid silently overwriting the source measurement.
4. Min-max scaling is included for demonstration. For predictive modelling, fit scaling parameters on the training split only to prevent data leakage.
5. For real data, maintain a read-only raw copy, document joins and units, and avoid committing confidential or personal data.

## Suggested GitHub repository description
Python project demonstrating data cleaning, missing-value handling, outlier detection, normalization, and quality validation for logistics analysis.
