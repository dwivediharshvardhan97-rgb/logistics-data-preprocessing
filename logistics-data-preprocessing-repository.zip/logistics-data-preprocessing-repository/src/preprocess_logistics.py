"""
Logistics Data Collection, Cleaning and Preprocessing
----------------------------------------------------
This project uses a SIMULATED teaching dataset. It is not real carrier/customer data.

Run from repository root:
    python -m pip install -r requirements.txt
    python src/preprocess_logistics.py

Outputs are written to outputs/:
    logistics_cleaned.csv
    data_quality_report.csv
    preprocessing_summary.json
"""
from pathlib import Path
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
INPUT_FILE = ROOT / "data" / "logistics_sample_raw.csv"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

NUMERIC_COLUMNS = ["distance_km", "delivery_days", "freight_cost_usd"]
CATEGORICAL_COLUMNS = ["region", "transport_mode"]
DATE_COLUMN = "dispatch_date"
ID_COLUMN = "shipment_id"


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Input dataset not found: {INPUT_FILE}. Keep the raw CSV in data/."
        )

    raw = pd.read_csv(INPUT_FILE)
    initial_rows, initial_columns = raw.shape
    report_rows = []

    # Profile missingness before changing the data.
    for column in raw.columns:
        report_rows.append({
            "stage": "before_cleaning",
            "check": "missing_values",
            "column": column,
            "count": int(raw[column].isna().sum()),
            "details": "Null values in original input"
        })

    exact_duplicates = int(raw.duplicated().sum())
    report_rows.append({
        "stage": "before_cleaning",
        "check": "exact_duplicate_rows",
        "column": "ALL",
        "count": exact_duplicates,
        "details": "Rows identical across every column"
    })

    df = raw.drop_duplicates().copy()

    # Standardize text fields, preserving missing values.
    for column in CATEGORICAL_COLUMNS:
        df[column] = df[column].astype("string").str.strip().str.title()

    # Convert types; invalid dates/numbers become missing and are audited.
    df[DATE_COLUMN] = pd.to_datetime(df[DATE_COLUMN], errors="coerce")
    for column in NUMERIC_COLUMNS:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    invalid_dates = int(df[DATE_COLUMN].isna().sum())
    report_rows.append({
        "stage": "after_type_conversion",
        "check": "invalid_or_missing_dates",
        "column": DATE_COLUMN,
        "count": invalid_dates,
        "details": "Unparseable dates converted to missing"
    })

    # Impossible numeric values are marked missing rather than silently retained.
    invalid_negative_days = int((df["delivery_days"] < 0).sum())
    invalid_nonpositive_distance = int((df["distance_km"] <= 0).sum())
    invalid_negative_cost = int((df["freight_cost_usd"] < 0).sum())

    df.loc[df["delivery_days"] < 0, "delivery_days"] = pd.NA
    df.loc[df["distance_km"] <= 0, "distance_km"] = pd.NA
    df.loc[df["freight_cost_usd"] < 0, "freight_cost_usd"] = pd.NA

    for name, count, column, details in [
        ("invalid_negative_delivery_days", invalid_negative_days, "delivery_days",
         "Negative elapsed duration marked missing"),
        ("invalid_nonpositive_distance", invalid_nonpositive_distance, "distance_km",
         "Non-positive distance marked missing"),
        ("invalid_negative_freight_cost", invalid_negative_cost, "freight_cost_usd",
         "Negative cost marked missing"),
    ]:
        report_rows.append({
            "stage": "after_validation",
            "check": name,
            "column": column,
            "count": count,
            "details": details
        })

    # Median imputation for numeric fields; categorical/date missingness is retained
    # unless it can be recovered from a trusted source.
    imputation_values = {}
    for column in NUMERIC_COLUMNS:
        median_value = df[column].median()
        if pd.isna(median_value):
            raise ValueError(f"Cannot impute {column}: the entire column is missing.")
        imputation_values[column] = float(median_value)
        missing_before = int(df[column].isna().sum())
        df[column] = df[column].fillna(median_value)
        report_rows.append({
            "stage": "after_imputation",
            "check": "numeric_values_imputed",
            "column": column,
            "count": missing_before,
            "details": f"Filled with median={median_value:.3f}"
        })

    # IQR outlier screening for freight cost; retain original and capped feature.
    q1 = float(df["freight_cost_usd"].quantile(0.25))
    q3 = float(df["freight_cost_usd"].quantile(0.75))
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    outlier_mask = (df["freight_cost_usd"] < lower_bound) | (
        df["freight_cost_usd"] > upper_bound
    )
    outlier_count = int(outlier_mask.sum())
    df["freight_cost_outlier_flag"] = outlier_mask.astype(int)
    df["freight_cost_usd_capped"] = df["freight_cost_usd"].clip(
        lower=lower_bound, upper=upper_bound
    )
    report_rows.append({
        "stage": "after_outlier_screening",
        "check": "freight_cost_iqr_outliers",
        "column": "freight_cost_usd",
        "count": outlier_count,
        "details": (
            f"Q1={q1:.2f}; Q3={q3:.2f}; IQR={iqr:.2f}; "
            f"lower={lower_bound:.2f}; upper={upper_bound:.2f}"
        )
    })

    # Min-max normalization. Keep raw-unit columns alongside scaled columns.
    scaled_columns = {
        "distance_km": "distance_km_scaled",
        "delivery_days": "delivery_days_scaled",
        "freight_cost_usd_capped": "freight_cost_scaled",
    }
    for source, target in scaled_columns.items():
        minimum = float(df[source].min())
        maximum = float(df[source].max())
        if maximum == minimum:
            df[target] = 0.0
        else:
            df[target] = (df[source] - minimum) / (maximum - minimum)

    # Final checks: duplicate count, numeric missingness and normalized bounds.
    final_duplicates = int(df.duplicated().sum())
    numeric_missing_after = {
        column: int(df[column].isna().sum()) for column in NUMERIC_COLUMNS
    }
    scaled_bounds = {}
    for column in scaled_columns.values():
        scaled_bounds[column] = {
            "min": round(float(df[column].min()), 6),
            "max": round(float(df[column].max()), 6),
            "within_0_1": bool(df[column].between(0, 1).all()),
        }

    # Report remaining missing dates/categories rather than inventing values.
    for column in df.columns:
        report_rows.append({
            "stage": "after_cleaning",
            "check": "missing_values",
            "column": column,
            "count": int(df[column].isna().sum()),
            "details": "Remaining null values after preprocessing"
        })

    cleaned_file = OUTPUT_DIR / "logistics_cleaned.csv"
    quality_file = OUTPUT_DIR / "data_quality_report.csv"
    summary_file = OUTPUT_DIR / "preprocessing_summary.json"

    # Keep date values ISO-formatted for portable CSV output.
    df.to_csv(cleaned_file, index=False, date_format="%Y-%m-%d")
    pd.DataFrame(report_rows).to_csv(quality_file, index=False)

    summary = {
        "dataset_type": "simulated teaching dataset",
        "input_file": str(INPUT_FILE.relative_to(ROOT)),
        "initial_rows": int(initial_rows),
        "initial_columns": int(initial_columns),
        "exact_duplicate_rows_removed": exact_duplicates,
        "invalid_negative_delivery_days": invalid_negative_days,
        "invalid_nonpositive_distance": invalid_nonpositive_distance,
        "invalid_negative_freight_cost": invalid_negative_cost,
        "invalid_or_missing_dispatch_dates_after_parsing": invalid_dates,
        "rows_after_duplicate_removal": int(len(df)),
        "rows_in_cleaned_output": int(len(df)),
        "numeric_medians_used": imputation_values,
        "freight_cost_iqr": {
            "q1": round(q1, 3),
            "q3": round(q3, 3),
            "iqr": round(iqr, 3),
            "lower_bound": round(lower_bound, 3),
            "upper_bound": round(upper_bound, 3),
            "outlier_count": outlier_count,
        },
        "numeric_missing_after_cleaning": numeric_missing_after,
        "final_exact_duplicate_rows": final_duplicates,
        "normalized_column_checks": scaled_bounds,
        "descriptive_statistics": {
            "mean_delivery_days": round(float(df["delivery_days"].mean()), 3),
            "median_delivery_days": round(float(df["delivery_days"].median()), 3),
            "mean_freight_cost_capped_usd": round(float(df["freight_cost_usd_capped"].mean()), 3),
            "mean_distance_km": round(float(df["distance_km"].mean()), 3),
        },
        "notes": [
            "Synthetic data only; not a real carrier dataset.",
            "IQR flags are investigation candidates, not automatic proof of error.",
            "Median imputation is a baseline and should be justified for real data.",
            "Normalization is shown for demonstration; fit scaling parameters on training data only in ML workflows."
        ]
    }
    summary_file.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("PREPROCESSING COMPLETED")
    print(f"Input shape: ({initial_rows}, {initial_columns})")
    print(f"Exact duplicate rows removed: {exact_duplicates}")
    print(f"Rows in cleaned output: {len(df)}")
    print(f"Negative delivery-day values corrected: {invalid_negative_days}")
    print(f"Freight-cost outliers flagged by IQR: {outlier_count}")
    print(f"Numeric missing values after cleaning: {numeric_missing_after}")
    print(f"Scaled features in range [0, 1]: {all(x['within_0_1'] for x in scaled_bounds.values())}")
    print(f"Saved cleaned data: {cleaned_file.relative_to(ROOT)}")
    print(f"Saved quality report: {quality_file.relative_to(ROOT)}")
    print(f"Saved summary: {summary_file.relative_to(ROOT)}")

    # Basic assertions make the run self-checking.
    assert final_duplicates == 0, "Duplicate rows remain in output."
    assert all(value == 0 for value in numeric_missing_after.values()), "Numeric missing values remain."
    assert all(x["within_0_1"] for x in scaled_bounds.values()), "A scaled feature is outside [0, 1]."
    assert len(df) == initial_rows - exact_duplicates, "Unexpected row-count change."
    print("VALIDATION PASSED: duplicate, numeric missingness, scaling and row-count checks passed.")


if __name__ == "__main__":
    main()
